/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        clinic: {
          50: '#eefbf6',
          100: '#d6f5e8',
          200: '#ade9d1',
          300: '#7ad8b6',
          400: '#48bf98',
          500: '#27a37d',
          600: '#1a8365',
          700: '#166853',
          800: '#155343',
          900: '#124539',
          950: '#08281f',
        },
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        card: '0 1px 2px 0 rgba(15, 23, 42, 0.04), 0 1px 6px -1px rgba(15, 23, 42, 0.06)',
      },
    },
  },
  plugins: [],
}