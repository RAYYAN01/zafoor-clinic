import { useState, useEffect } from 'react'
import { ThemeProvider } from './context/ThemeContext'
import { DataProvider } from './context/DataContext'
import Sidebar from './components/Sidebar'
import Topbar from './components/Topbar'
import Dashboard from './components/Dashboard'
import Patients from './components/Patients'
import Services from './components/Services'
import Billing from './components/Billing'
import Stock from './components/Stock'
import Labs from './components/Labs'
import Messages from './components/Messages'
import Financials from './components/Financials'
import ToastContainer from './components/Toast'
import { X, ShieldCheck, UserCheck, Edit2, Save } from 'lucide-react'

const defaultProfile = {
  name: 'Dr. Mufeeda Roohi',
  email: 'dr.mufeeda@zafoorclinic.com',
  specialization: 'Skin Care & General Medicine',
  clinic: 'Zafoor Clinic',
}

export default function App() {
  const [active, setActive] = useState('dashboard')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [role, setRole] = useState('doctor')
  const [isLoggedIn, setIsLoggedIn] = useState(true)
  const [activeModal, setActiveModal] = useState(null)

  const [userProfile, setUserProfile] = useState(() => {
    const saved = localStorage.getItem('zafoor_user_profile')
    return saved ? JSON.parse(saved) : defaultProfile
  })

  const [editProfile, setEditProfile] = useState(userProfile)
  const [isEditing, setIsEditing] = useState(false)

  useEffect(() => {
    localStorage.setItem('zafoor_user_profile', JSON.stringify(userProfile))
  }, [userProfile])

  const handleSaveProfile = (e) => {
    e.preventDefault()
    setUserProfile(editProfile)
    setIsEditing(false)
  }

  return (
    <ThemeProvider>
      <DataProvider>
        <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex font-sans">
          <Sidebar active={active} setActive={setActive} open={sidebarOpen} setOpen={setSidebarOpen} role={role} />

          <div className="flex-1 min-w-0 flex flex-col">
            <Topbar
              active={active}
              setOpen={setSidebarOpen}
              role={role}
              setRole={setRole}
              isLoggedIn={isLoggedIn}
              setIsLoggedIn={setIsLoggedIn}
              userProfile={userProfile}
              onOpenModal={(modal) => {
                setEditProfile(userProfile)
                setIsEditing(false)
                setActiveModal(modal)
              }}
            />

            <main className="flex-1 p-4 sm:p-6 max-w-7xl w-full mx-auto">
              {!isLoggedIn ? (
                <div className="flex flex-col items-center justify-center py-20 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 shadow-sm">
                  <div className="w-16 h-16 rounded-2xl bg-teal-50 dark:bg-teal-900/40 text-teal-600 dark:text-teal-400 flex items-center justify-center mb-4">
                    <UserCheck size={32} />
                  </div>
                  <h2 className="text-2xl font-extrabold">You are Logged Out</h2>
                  <p className="text-sm text-slate-500 dark:text-slate-400 mt-2 max-w-sm">
                    Please log back in from the profile icon menu at the top right to access patient records and clinic operations.
                  </p>
                  <button
                    onClick={() => setIsLoggedIn(true)}
                    className="mt-6 px-6 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold rounded-xl shadow-sm transition-all"
                  >
                    Log In as {userProfile.name}
                  </button>
                </div>
              ) : (
                <>
                  {active === 'dashboard' && <Dashboard setActive={setActive} />}
                  {active === 'patients' && (role === 'doctor' ? <Patients role={role} /> : <div className="p-10 text-center font-serif text-stone-500">Access Restricted to Doctor.</div>)}
                  {active === 'financials' && <Financials role={role} />}
                  {active === 'messages' && <Messages />}
                  {active === 'billing' && <Billing />}
                  {active === 'services' && <Services />}
                  {active === 'stock' && <Stock />}
                  {active === 'labs' && <Labs />}
                </>
              )}
            </main>
          </div>

          {activeModal === 'account' && (
            <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl animate-fade-in">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                  <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">Account Settings</h3>
                  <button onClick={() => setActiveModal(null)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                    <X size={18} />
                  </button>
                </div>

                {!isEditing ? (
                  <div className="py-4 space-y-4 text-sm">
                    <div className="bg-slate-50 dark:bg-slate-800/50 p-3 rounded-xl border border-slate-100 dark:border-slate-800">
                      <p className="text-xs font-semibold text-slate-400">Practitioner Name</p>
                      <p className="font-bold text-slate-800 dark:text-slate-200 mt-0.5">{userProfile.name}</p>
                    </div>

                    <div className="bg-slate-50 dark:bg-slate-800/50 p-3 rounded-xl border border-slate-100 dark:border-slate-800">
                      <p className="text-xs font-semibold text-slate-400">Email Address</p>
                      <p className="font-bold text-slate-800 dark:text-slate-200 mt-0.5">{userProfile.email}</p>
                    </div>

                    <div className="bg-slate-50 dark:bg-slate-800/50 p-3 rounded-xl border border-slate-100 dark:border-slate-800">
                      <p className="text-xs font-semibold text-slate-400">Specialization</p>
                      <p className="font-bold text-slate-800 dark:text-slate-200 mt-0.5">{userProfile.specialization}</p>
                    </div>

                    <div className="bg-slate-50 dark:bg-slate-800/50 p-3 rounded-xl border border-slate-100 dark:border-slate-800">
                      <p className="text-xs font-semibold text-slate-400">Clinic Name</p>
                      <p className="font-bold text-slate-800 dark:text-slate-200 mt-0.5">{userProfile.clinic}</p>
                    </div>

                    <div className="flex justify-between items-center pt-2">
                      <button
                        type="button"
                        onClick={() => setIsEditing(true)}
                        className="flex items-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-teal-50 dark:hover:bg-teal-950/40 text-slate-700 dark:text-slate-300 hover:text-teal-600 dark:hover:text-teal-400 text-xs font-bold rounded-xl transition-colors"
                      >
                        <Edit2 size={14} /> Edit Details
                      </button>
                      <button onClick={() => setActiveModal(null)} className="px-4 py-2 bg-teal-600 text-white rounded-xl text-xs font-bold">
                        Done
                      </button>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleSaveProfile} className="py-4 space-y-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">Practitioner Name</label>
                      <input
                        type="text"
                        value={editProfile.name}
                        onChange={(e) => setEditProfile({ ...editProfile, name: e.target.value })}
                        className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-sm outline-none focus:ring-2 focus:ring-teal-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">Email Address</label>
                      <input
                        type="email"
                        value={editProfile.email}
                        onChange={(e) => setEditProfile({ ...editProfile, email: e.target.value })}
                        className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-sm outline-none focus:ring-2 focus:ring-teal-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">Specialization</label>
                      <input
                        type="text"
                        value={editProfile.specialization}
                        onChange={(e) => setEditProfile({ ...editProfile, specialization: e.target.value })}
                        className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-sm outline-none focus:ring-2 focus:ring-teal-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">Clinic Name</label>
                      <input
                        type="text"
                        value={editProfile.clinic}
                        onChange={(e) => setEditProfile({ ...editProfile, clinic: e.target.value })}
                        className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-sm outline-none focus:ring-2 focus:ring-teal-500"
                        required
                      />
                    </div>

                    <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                      <button
                        type="button"
                        onClick={() => setIsEditing(false)}
                        className="px-3 py-1.5 text-xs font-semibold text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="flex items-center gap-1.5 px-4 py-1.5 bg-teal-600 text-white text-xs font-bold rounded-lg shadow-sm"
                      >
                        <Save size={14} /> Save Profile
                      </button>
                    </div>
                  </form>
                )}
              </div>
            </div>
          )}

          {activeModal === 'privacy' && (
            <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4">
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl animate-fade-in">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-2 text-teal-600 dark:text-teal-400">
                    <ShieldCheck size={20} />
                    <h3 className="text-lg font-bold text-slate-900 dark:text-slate-100">Privacy & Data Security</h3>
                  </div>
                  <button onClick={() => setActiveModal(null)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                    <X size={18} />
                  </button>
                </div>
                <div className="py-4 space-y-3 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  <p>• <strong>Local Data Storage:</strong> All current patient and billing records are saved locally in browser memory (`localStorage`).</p>
                  <p>• <strong>Access Security:</strong> Role-based access ensures Receptionists and Doctors have tailored dashboard views.</p>
                  <p>• <strong>Zero External Leakage:</strong> No telemetry or patient clinical data is shared with external tracking services.</p>
                </div>
                <button
                  onClick={() => setActiveModal(null)}
                  className="w-full py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition-all"
                >
                  Understood
                </button>
              </div>
            </div>
          )}

          <ToastContainer />
        </div>
      </DataProvider>
    </ThemeProvider>
  )
}