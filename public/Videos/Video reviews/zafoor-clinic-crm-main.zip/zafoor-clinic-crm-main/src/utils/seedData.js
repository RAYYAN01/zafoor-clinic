// Initial demo data so the dashboard looks alive on first run.
// Everything here is editable/deletable once the app is running.

export const seedPatients = [
  {
    id: 'P-1001',
    name: 'Ahmed Kareem',
    age: 34,
    gender: 'Male',
    phone: '+91 98765 43210',
    condition: 'Acne treatment, follow-up',
    lastVisit: '2026-07-28',
    doctor: 'Dr. Mufeeda Roohi',
    notes: 'Prescribed topical retinoid. Review in 3 weeks.',
    history: [
      { date: '2026-07-28', note: 'Mild cystic acne on jawline. Started Adapalene 0.1% gel nightly.' },
      { date: '2026-06-10', note: 'Initial consult. Skin type: oily. No known allergies.' },
    ],
  },
  {
    id: 'P-1002',
    name: 'Fathima Zubair',
    age: 27,
    gender: 'Female',
    phone: '+91 90123 45678',
    condition: 'General checkup, seasonal allergy',
    lastVisit: '2026-08-01',
    doctor: 'Dr. Mufeeda Roohi',
    notes: 'Antihistamine course for 5 days.',
    history: [
      { date: '2026-08-01', note: 'Sneezing, mild rash. Prescribed Cetirizine 10mg OD.' },
    ],
  },
  {
    id: 'P-1003',
    name: 'Rahul Menon',
    age: 45,
    gender: 'Male',
    phone: '+91 91234 56789',
    condition: 'Diabetes monitoring',
    lastVisit: '2026-07-15',
    doctor: 'Dr. Mufeeda Roohi',
    notes: 'HbA1c improving. Continue current dosage.',
    history: [
      { date: '2026-07-15', note: 'HbA1c 6.8%. Continue Metformin 500mg BD.' },
      { date: '2026-04-02', note: 'HbA1c 7.4%. Diet counseling given.' },
    ],
  },
  {
    id: 'P-1004',
    name: 'Priya Sundaram',
    age: 31,
    gender: 'Female',
    phone: '+91 99887 66554',
    condition: 'Skincare — pigmentation',
    lastVisit: '2026-07-30',
    doctor: 'Dr. Mufeeda Roohi',
    notes: 'Chemical peel session 2 of 4 scheduled.',
    history: [
      { date: '2026-07-30', note: 'Second glycolic acid peel session completed. Tolerated well.' },
    ],
  },
]

export const seedStock = [
  { id: 'M-01', name: 'Adapalene 0.1% Gel', category: 'Skincare', batch: 'AD2026A', qty: 42, reorderLevel: 15, expiry: '2027-03-01', unit: 'tubes' },
  { id: 'M-02', name: 'Cetirizine 10mg', category: 'Medicine', batch: 'CT119', qty: 8, reorderLevel: 20, expiry: '2026-12-15', unit: 'strips' },
  { id: 'M-03', name: 'Metformin 500mg', category: 'Medicine', batch: 'MF204', qty: 60, reorderLevel: 25, expiry: '2027-05-20', unit: 'strips' },
  { id: 'M-04', name: 'Glycolic Acid Peel 30%', category: 'Skincare', batch: 'GAP07', qty: 5, reorderLevel: 6, expiry: '2026-09-10', unit: 'bottles' },
  { id: 'M-05', name: 'Sunscreen SPF 50', category: 'Skincare', batch: 'SS2026', qty: 30, reorderLevel: 10, expiry: '2027-01-30', unit: 'tubes' },
  { id: 'M-06', name: 'Surgical Gloves (M)', category: 'Consumable', batch: 'GLV441', qty: 120, reorderLevel: 50, expiry: '2028-01-01', unit: 'pairs' },
]

export const seedLabs = [
  { id: 'L-201', patient: 'Ahmed Kareem', patientId: 'P-1001', test: 'Skin Culture & Sensitivity', status: 'Completed', orderedDate: '2026-07-28', resultDate: '2026-07-30', result: 'No bacterial growth' },
  { id: 'L-202', patient: 'Rahul Menon', patientId: 'P-1003', test: 'HbA1c', status: 'Completed', orderedDate: '2026-07-15', resultDate: '2026-07-16', result: '6.8%' },
  { id: 'L-203', patient: 'Fathima Zubair', patientId: 'P-1002', test: 'CBC (Complete Blood Count)', status: 'In Progress', orderedDate: '2026-08-01', resultDate: null, result: null },
  { id: 'L-204', patient: 'Priya Sundaram', patientId: 'P-1004', test: 'Allergy Panel', status: 'Pending', orderedDate: '2026-08-04', resultDate: null, result: null },
]

export const seedMessages = [
  { id: 'MSG-01', patient: 'Ahmed Kareem', patientId: 'P-1001', channel: 'WhatsApp', type: 'Follow-up reminder', message: 'Reminder: your follow-up visit is on Aug 18. Reply CONFIRM to confirm.', status: 'Sent', date: '2026-08-04' },
  { id: 'MSG-02', patient: 'Fathima Zubair', patientId: 'P-1002', channel: 'SMS', type: 'Appointment reminder', message: 'Your appointment with Dr. Roohi is tomorrow at 11:00 AM.', status: 'Sent', date: '2026-08-04' },
  { id: 'MSG-03', patient: 'Priya Sundaram', patientId: 'P-1004', channel: 'WhatsApp', type: 'Skincare tip', message: 'Tip: Apply sunscreen 20 mins before stepping out, reapply every 3 hours.', status: 'Scheduled', date: '2026-08-06' },
  { id: 'MSG-04', patient: 'Rahul Menon', patientId: 'P-1003', channel: 'SMS', type: 'Lab result ready', message: 'Your HbA1c report is ready. Please collect it at the front desk.', status: 'Sent', date: '2026-07-16' },
]