import { Menu, Bell, Moon, Sun, User, Shield, LogIn, LogOut, X, Check } from 'lucide-react';
import { useState, useEffect, useRef } from 'react';

export default function Topbar({ setOpen, role, setRole, isLoggedIn = true, userProfile, setIsLoggedIn, setUserProfile }) {
  const [darkMode, setDarkMode] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showAccountMenu, setShowAccountMenu] = useState(false);

  // Modal states for Account and Privacy
  const [showAccountModal, setShowAccountModal] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  // Editable account form state
  const [profileForm, setProfileForm] = useState({
    name: userProfile?.name || (role === 'doctor' ? 'Dr. Mufeeda Roohi' : 'Receptionist Staff'),
    email: userProfile?.email || 'staff@zafoorclinic.com'
  });

  const notificationsRef = useRef(null);
  const accountRef = useRef(null);

  // Close dropdowns when clicking outside
  useEffect(() => {
    function handleClickOutside(event) {
      if (notificationsRef.current && !notificationsRef.current.contains(event.target)) {
        setShowNotifications(false);
      }
      if (accountRef.current && !accountRef.current.contains(event.target)) {
        setShowAccountMenu(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const mockNotifications = [
    { id: 1, title: 'New Appointment', desc: 'Patient booked for General Consultation.', time: '5m ago', unread: true },
    { id: 2, title: 'Low Stock Alert', desc: 'Paracetamol strips are running low.', time: '1h ago', unread: true },
    { id: 3, title: 'Lab Report Ready', desc: 'Blood test results uploaded for review.', time: '3h ago', unread: false },
    { id: 4, title: 'System Update', desc: 'Clinic management system updated to v2.4.', time: '1d ago', unread: false },
  ];

  const handleSaveProfile = (e) => {
    e.preventDefault();
    if (setUserProfile) {
      setUserProfile(profileForm);
    }
    setSuccessMessage('Account details updated successfully.');
    setTimeout(() => {
      setSuccessMessage('');
      setShowAccountModal(false);
    }, 1500);
  };

  const handleAuthToggle = () => {
    if (isLoggedIn) {
      if (setIsLoggedIn) setIsLoggedIn(false);
    } else {
      if (setIsLoggedIn) setIsLoggedIn(true);
    }
    setShowAccountMenu(false);
  };

  return (
    <>
      <header className="h-20 bg-white/90 dark:bg-stone-900/90 backdrop-blur-md border-b border-stone-200/80 dark:border-stone-800/80 px-8 flex justify-between items-center sticky top-0 z-50 transition-colors duration-300">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setOpen(true)} 
            className="p-2.5 rounded-xl bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-700 transition-colors md:hidden"
          >
            <Menu size={20} />
          </button>
          <div>
            <h1 className="text-xl font-serif font-semibold text-stone-900 dark:text-stone-50">Zafoor Clinic</h1>
            <p className="text-xs font-sans text-stone-500 dark:text-stone-400">Welcome back, {userProfile?.name || role || 'User'}</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Role Selector Dropdown */}
          <div className="flex items-center gap-2 bg-stone-100 dark:bg-stone-800 px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700">
            <span className="text-xs font-medium text-stone-400">Role:</span>
            <select 
              value={role || 'doctor'} 
              onChange={(e) => setRole && setRole(e.target.value)} 
              className="bg-transparent text-xs font-semibold text-stone-800 dark:text-stone-200 outline-none cursor-pointer"
            >
              <option value="doctor" className="dark:bg-stone-900">Doctor</option>
              <option value="receptionist" className="dark:bg-stone-900">Receptionist</option>
            </select>
          </div>

          <button 
            onClick={() => setDarkMode(!darkMode)} 
            className="p-2.5 rounded-xl bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-700 transition-colors"
          >
            {darkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>

          {/* Notifications Dropdown Container */}
          <div className="relative" ref={notificationsRef}>
            <button 
              onClick={() => {
                setShowNotifications(!showNotifications);
                setShowAccountMenu(false);
              }} 
              className="p-2.5 rounded-xl bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-700 transition-colors relative"
            >
              <Bell size={20} />
              <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-rose-500"></span>
            </button>

            {showNotifications && (
              <div className="absolute right-0 mt-3 w-80 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl shadow-2xl overflow-hidden z-[100] animate-fade-in">
                <div className="p-4 border-b border-stone-100 dark:border-stone-800 flex items-center justify-between bg-stone-50/50 dark:bg-stone-800/30">
                  <h3 className="font-serif font-semibold text-stone-900 dark:text-stone-50 text-sm">Notifications</h3>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-stone-200 dark:bg-stone-700 text-stone-700 dark:text-stone-300 font-medium">4 New</span>
                </div>
                <div className="divide-y divide-stone-100 dark:divide-stone-800 max-h-80 overflow-y-auto">
                  {mockNotifications.map((notif) => (
                    <div key={notif.id} className="p-3.5 hover:bg-stone-50 dark:hover:bg-stone-800/50 transition-colors cursor-pointer flex gap-3 items-start">
                      <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${notif.unread ? 'bg-rose-500' : 'bg-transparent'}`} />
                      <div>
                        <p className="text-xs font-semibold text-stone-900 dark:text-stone-100">{notif.title}</p>
                        <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5 leading-relaxed">{notif.desc}</p>
                        <p className="text-[10px] text-stone-400 dark:text-stone-500 mt-1">{notif.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* User Account Menu Container */}
          <div className="relative hidden sm:block" ref={accountRef}>
            <button 
              onClick={() => {
                setShowAccountMenu(!showAccountMenu);
                setShowNotifications(false);
              }}
              className="flex items-center gap-3 pl-3 border-l border-stone-200 dark:border-stone-800 text-left focus:outline-none group"
            >
              <div className="w-10 h-10 rounded-xl bg-stone-900 dark:bg-stone-100 text-white dark:text-stone-900 flex items-center justify-center font-bold text-sm shadow-md group-hover:scale-105 transition-transform">
                {role ? role.substring(0, 2).toUpperCase() : 'ZC'}
              </div>
              <div>
                <p className="text-sm font-semibold text-stone-900 dark:text-stone-50">{userProfile?.name || role || 'Clinic Staff'}</p>
                <p className="text-xs text-stone-500 dark:text-stone-400">{isLoggedIn ? (role || 'Active User') : 'Guest'}</p>
              </div>
            </button>

            {showAccountMenu && (
              <div className="absolute right-0 mt-3 w-56 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl shadow-2xl overflow-hidden z-[100] animate-fade-in py-2">
                <div className="px-4 py-2.5 border-b border-stone-100 dark:border-stone-800 mb-1 bg-stone-50/50 dark:bg-stone-800/30">
                  <p className="text-xs font-semibold text-stone-900 dark:text-stone-100">{userProfile?.name || role || 'Clinic Staff'}</p>
                  <p className="text-[11px] text-stone-400 truncate mt-0.5">{userProfile?.email || 'staff@zafoorclinic.com'}</p>
                </div>
                <button 
                  onClick={() => {
                    setShowAccountMenu(false);
                    setShowAccountModal(true);
                  }}
                  className="w-full px-4 py-2.5 text-left text-xs font-medium text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 flex items-center gap-2.5 transition-colors"
                >
                  <User size={15} /> Account
                </button>
                <button 
                  onClick={() => {
                    setShowAccountMenu(false);
                    setShowPrivacyModal(true);
                  }}
                  className="w-full px-4 py-2.5 text-left text-xs font-medium text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 flex items-center gap-2.5 transition-colors"
                >
                  <Shield size={15} /> Privacy
                </button>
                <div className="my-1 border-t border-stone-100 dark:border-stone-800"></div>
                {isLoggedIn ? (
                  <button 
                    onClick={handleAuthToggle}
                    className="w-full px-4 py-2.5 text-left text-xs font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center gap-2.5 transition-colors"
                  >
                    <LogOut size={15} /> Sign Out
                  </button>
                ) : (
                  <button 
                    onClick={handleAuthToggle}
                    className="w-full px-4 py-2.5 text-left text-xs font-medium text-stone-900 dark:text-stone-100 hover:bg-stone-100 dark:hover:bg-stone-800 flex items-center gap-2.5 transition-colors"
                  >
                    <LogIn size={15} /> Sign In
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Account Modal */}
      {showAccountModal && (
        <div className="fixed inset-0 z-50 bg-stone-900/40 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={() => setShowAccountModal(false)}>
          <div onClick={(e) => e.stopPropagation()} className="w-full max-w-md rounded-3xl bg-white dark:bg-stone-900 p-8 space-y-6 shadow-2xl border border-stone-200 dark:border-stone-800">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-stone-900 dark:bg-stone-100 text-white dark:text-stone-900 flex items-center justify-center font-bold text-sm">
                  <User size={18} />
                </div>
                <div>
                  <h3 className="font-serif font-semibold text-xl text-stone-900 dark:text-stone-50">Account Settings</h3>
                  <p className="text-xs text-stone-500">Manage your profile credentials and role.</p>
                </div>
              </div>
              <button type="button" onClick={() => setShowAccountModal(false)} className="text-stone-400 hover:text-stone-900 dark:hover:text-stone-50">
                <X size={20} />
              </button>
            </div>

            {successMessage && (
              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 text-emerald-800 dark:text-emerald-300 rounded-xl flex items-center gap-2 text-xs font-semibold">
                <Check size={16} /> {successMessage}
              </div>
            )}

            <form onSubmit={handleSaveProfile} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-600 dark:text-stone-400 uppercase tracking-wider mb-1.5">Full Name</label>
                <input
                  required
                  type="text"
                  value={profileForm.name}
                  onChange={(e) => setProfileForm({ ...profileForm, name: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-sm text-stone-900 dark:text-stone-100 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-600 dark:text-stone-400 uppercase tracking-wider mb-1.5">Email Address</label>
                <input
                  required
                  type="email"
                  value={profileForm.email}
                  onChange={(e) => setProfileForm({ ...profileForm, email: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-sm text-stone-900 dark:text-stone-100 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-600 dark:text-stone-400 uppercase tracking-wider mb-1.5">Current Role</label>
                <input
                  disabled
                  type="text"
                  value={role ? role.toUpperCase() : 'DOCTOR'}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-100 dark:bg-stone-800/50 text-sm text-stone-500 cursor-not-allowed outline-none uppercase font-semibold"
                />
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowAccountModal(false)}
                  className="px-5 py-2.5 rounded-xl border border-stone-200 dark:border-stone-700 text-stone-600 dark:text-stone-300 text-sm font-semibold hover:bg-stone-50 dark:hover:bg-stone-800 transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 dark:bg-stone-100 dark:hover:bg-stone-200 text-white dark:text-stone-900 text-sm font-semibold transition-all shadow-md"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Privacy Modal */}
      {showPrivacyModal && (
        <div className="fixed inset-0 z-50 bg-stone-900/40 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={() => setShowPrivacyModal(false)}>
          <div onClick={(e) => e.stopPropagation()} className="w-full max-w-lg rounded-3xl bg-white dark:bg-stone-900 p-8 space-y-6 shadow-2xl border border-stone-200 dark:border-stone-800">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-stone-900 dark:bg-stone-100 text-white dark:text-stone-900 flex items-center justify-center font-bold text-sm">
                  <Shield size={18} />
                </div>
                <div>
                  <h3 className="font-serif font-semibold text-xl text-stone-900 dark:text-stone-50">Privacy & Security</h3>
                  <p className="text-xs text-stone-500">Zafoor Clinic Data Protection & Compliance</p>
                </div>
              </div>
              <button type="button" onClick={() => setShowPrivacyModal(false)} className="text-stone-400 hover:text-stone-900 dark:hover:text-stone-50">
                <X size={20} />
              </button>
            </div>

            <div className="space-y-4 text-xs text-stone-600 dark:text-stone-300 leading-relaxed max-h-72 overflow-y-auto pr-2">
              <div className="p-3.5 bg-stone-50 dark:bg-stone-800/40 rounded-2xl border border-stone-100 dark:border-stone-800">
                <p className="font-semibold text-stone-900 dark:text-stone-100 mb-1">Local Secure Storage</p>
                <p>All patient records, financial ledgers, and lab reports are securely cached using encrypted browser local storage to maintain immediate availability while respecting patient confidentiality.</p>
              </div>
              <div className="p-3.5 bg-stone-50 dark:bg-stone-800/40 rounded-2xl border border-stone-100 dark:border-stone-800">
                <p className="font-semibold text-stone-900 dark:text-stone-100 mb-1">Role-Based Access Control (RBAC)</p>
                <p>Sensitive financial ledgers and proprietary clinic data are strictly restricted based on authenticated user roles (Doctor vs. Receptionist).</p>
              </div>
              <div className="p-3.5 bg-stone-50 dark:bg-stone-800/40 rounded-2xl border border-stone-100 dark:border-stone-800">
                <p className="font-semibold text-stone-900 dark:text-stone-100 mb-1">Compliance Standards</p>
                <p>Designed to adhere to high-standard medical record-keeping guidelines, safeguarding personally identifiable information (PII) of all visitors and patients.</p>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setShowPrivacyModal(false)}
                className="px-6 py-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 dark:bg-stone-100 dark:hover:bg-stone-200 text-white dark:text-stone-900 text-sm font-semibold transition-all shadow-md"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}