import React, { useState, useEffect } from 'react';
import { Receipt, CreditCard, X } from 'lucide-react';

export default function Billing() {
  const [bills, setBills] = useState(() => {
    const saved = localStorage.getItem('clinic_invoices');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return [
      { id: 'INV-501', patient: 'Rahul Sharma', amount: '₹2,500', paymentMode: 'UPI', status: 'Paid', date: 'Aug 06, 2026' },
      { id: 'INV-502', patient: 'Priya Patel', amount: '₹1,800', paymentMode: 'Cash', status: 'Pending', date: 'Aug 05, 2026' }
    ];
  });

  useEffect(() => {
    localStorage.setItem('clinic_invoices', JSON.stringify(bills));
  }, [bills]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newPatient, setNewPatient] = useState('');
  const [newAmount, setNewAmount] = useState('');
  const [paymentMode, setPaymentMode] = useState('UPI');
  const [status, setStatus] = useState('Pending');

  const handleAddBill = (e) => {
    e.preventDefault();
    if (!newPatient || !newAmount) return;
    const nextId = `INV-${501 + bills.length}`;
    const today = new Date().toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
    setBills([{ id: nextId, patient: newPatient, amount: `₹${newAmount}`, paymentMode, status, date: today }, ...bills]);
    setNewPatient('');
    setNewAmount('');
    setPaymentMode('UPI');
    setStatus('Pending');
    setIsModalOpen(false);
  };

  return (
    <div className="p-8 lg:p-12 bg-gradient-to-br from-[#F9F8F6] to-[#EBE9E1] dark:from-stone-950 dark:to-stone-900 min-h-screen transition-colors duration-300 relative">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-10">
          <div>
            <h2 className="text-3xl font-serif text-stone-900 dark:text-stone-50 font-semibold tracking-tight">Billing & Invoices</h2>
            <p className="text-sm font-sans text-stone-600 dark:text-stone-400 mt-2">Manage patient payments and financial logs.</p>
          </div>
          <button onClick={() => setIsModalOpen(true)} className="flex items-center gap-2 px-6 py-3 bg-stone-900 dark:bg-stone-100 text-white dark:text-stone-900 text-sm font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all">
            <CreditCard size={18} /> New Invoice
          </button>
        </div>

        <div className="bg-white/40 dark:bg-stone-900/40 backdrop-blur-xl border border-white/60 dark:border-stone-800/50 rounded-3xl shadow-xl overflow-hidden transition-all duration-300">
          <div className="p-6 border-b border-white/50 dark:border-stone-800/50 flex items-center gap-3">
            <Receipt className="text-stone-600 dark:text-stone-400" size={20} />
            <h3 className="font-serif font-semibold text-stone-900 dark:text-stone-50">Recent Invoices</h3>
          </div>
          <div className="divide-y divide-white/50 dark:divide-stone-800/50">
            {bills.map((bill) => (
              <div key={bill.id} className="p-6 flex items-center justify-between hover:bg-white/30 dark:hover:bg-stone-800/30 transition-colors">
                <div>
                  <p className="font-bold text-stone-900 dark:text-stone-100">{bill.patient}</p>
                  <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
                    {bill.id} • Amount: {bill.amount} • Mode: <span className="font-semibold text-stone-700 dark:text-stone-300">{bill.paymentMode || 'UPI'}</span>
                  </p>
                </div>
                <div className="text-right flex items-center gap-4">
                  <p className="text-xs text-stone-500 dark:text-stone-400 mr-2">{bill.date}</p>
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${bill.status === 'Paid' ? 'bg-stone-800 text-white dark:bg-stone-200 dark:text-stone-900' : 'bg-transparent border border-stone-400 text-stone-600 dark:text-stone-300'}`}>
                    {bill.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-stone-900/40 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-stone-900 rounded-3xl p-8 max-w-md w-full shadow-2xl relative">
            <button onClick={() => setIsModalOpen(false)} className="absolute top-6 right-6 text-stone-400 hover:text-stone-900 dark:hover:text-stone-50"><X size={20}/></button>
            <h3 className="text-xl font-serif font-semibold mb-6 text-stone-900 dark:text-stone-50">Create New Invoice</h3>
            <form onSubmit={handleAddBill} className="space-y-4">
              <div>
                <label className="text-sm font-semibold text-stone-700 dark:text-stone-300">Patient Name</label>
                <input type="text" value={newPatient} onChange={(e) => setNewPatient(e.target.value)} className="w-full mt-1 p-3 rounded-xl bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 outline-none text-stone-900 dark:text-stone-100" required />
              </div>
              <div>
                <label className="text-sm font-semibold text-stone-700 dark:text-stone-300">Amount (₹)</label>
                <input type="text" value={newAmount} onChange={(e) => setNewAmount(e.target.value)} className="w-full mt-1 p-3 rounded-xl bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 outline-none text-stone-900 dark:text-stone-100" required />
              </div>
              <div>
                <label className="text-sm font-semibold text-stone-700 dark:text-stone-300 block mb-2">Payment Mode</label>
                <div className="flex gap-2">
                  {['Cash', 'Card', 'UPI'].map((mode) => (
                    <button
                      type="button"
                      key={mode}
                      onClick={() => setPaymentMode(mode)}
                      className={`flex-1 py-2.5 rounded-xl text-xs font-semibold border transition-all ${
                        paymentMode === mode
                          ? 'bg-stone-900 text-white dark:bg-stone-100 dark:text-stone-900 border-stone-900 dark:border-stone-100 shadow-sm'
                          : 'bg-stone-50 dark:bg-stone-800 text-stone-600 dark:text-stone-300 border-stone-200 dark:border-stone-700 hover:border-stone-400'
                      }`}
                    >
                      {mode}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-sm font-semibold text-stone-700 dark:text-stone-300 block mb-2">Payment Status</label>
                <div className="flex gap-2">
                  {['Paid', 'Pending'].map((st) => (
                    <button
                      type="button"
                      key={st}
                      onClick={() => setStatus(st)}
                      className={`flex-1 py-2.5 rounded-xl text-xs font-semibold border transition-all ${
                        status === st
                          ? 'bg-stone-900 text-white dark:bg-stone-100 dark:text-stone-900 border-stone-900 dark:border-stone-100 shadow-sm'
                          : 'bg-stone-50 dark:bg-stone-800 text-stone-600 dark:text-stone-300 border-stone-200 dark:border-stone-700 hover:border-stone-400'
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </div>
              <button type="submit" className="w-full py-3 bg-stone-900 dark:bg-stone-100 text-white dark:text-stone-900 rounded-xl font-bold mt-4 hover:opacity-90">Generate Invoice</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}