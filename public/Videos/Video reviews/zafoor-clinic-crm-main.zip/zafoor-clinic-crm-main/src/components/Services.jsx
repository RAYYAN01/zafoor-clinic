import React, { useState, useEffect } from 'react';
import { Stethoscope, Sparkles, Activity, Plus, X, Calendar, Clock } from 'lucide-react';

export default function Services() {
  const servicesList = [
    {
      title: 'Cosmetology',
      description: 'Advanced aesthetic and skin rejuvenation treatments tailored to your beauty goals.',
      icon: Sparkles,
      items: [
        'PRP & GFC',
        'Laser Treatments',
        'Weight Reduction',
        'Hairfall & Dandruff Treatment',
        'Skin Boosters',
        'Chemical Peels & Facials',
        'Acne Treatment'
      ]
    },
    {
      title: 'Diabetology',
      description: 'Comprehensive diabetes management, metabolic profiling, and complication screening.',
      icon: Activity,
      items: [
        'HbA1c Testing',
        'FBS & PPBS',
        'Complication Checklists',
        'Vital Monitoring',
        'Diabetic Footcare'
      ]
    },
    {
      title: 'General Medicine',
      description: 'Holistic primary healthcare, specialist screenings, and family wellness.',
      icon: Stethoscope,
      items: [
        'Thyroid Care',
        'Pediatrics',
        'Gynecology',
        'Cholesterol Management',
        'General Consultation'
      ]
    }
  ];

  const [patients, setPatients] = useState(() => {
    const saved = localStorage.getItem('clinic_service_records');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return [
      { id: 1, name: 'Aarav Sharma', service: 'PRP & GFC', date: '2026-06-10', time: '10:30 AM' },
      { id: 2, name: 'Priya Patel', service: 'HbA1c Testing', date: '2026-06-11', time: '11:15 AM' },
      { id: 3, name: 'Rahul Verma', service: 'Thyroid Care', date: '2026-06-12', time: '02:00 PM' },
      { id: 4, name: 'Sneha Gupta', service: 'Chemical Peels & Facials', date: '2026-06-13', time: '04:30 PM' }
    ];
  });

  useEffect(() => {
    localStorage.setItem('clinic_service_records', JSON.stringify(patients));
  }, [patients]);

  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({
    name: '',
    service: 'PRP & GFC',
    date: new Date().toISOString().split('T')[0],
    time: '10:00 AM'
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name || !form.date || !form.time) return;
    const newRecord = {
      id: Date.now(),
      ...form
    };
    setPatients([newRecord, ...patients]);
    setForm({
      name: '',
      service: 'PRP & GFC',
      date: new Date().toISOString().split('T')[0],
      time: '10:00 AM'
    });
    setShowModal(false);
  };

  return (
    <div className="p-8 lg:p-12 bg-gradient-to-br from-[#F9F8F6] to-[#EBE9E1] dark:from-stone-950 dark:to-stone-900 min-h-screen transition-colors duration-300 relative space-y-12">
      <div className="max-w-6xl mx-auto space-y-12">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-serif text-stone-900 dark:text-stone-50 font-semibold tracking-tight">Clinical Services</h2>
            <p className="text-sm font-sans text-stone-600 dark:text-stone-400 mt-2">Explore available treatments and specialized medical care modules.</p>
          </div>
        </div>

        {/* Services Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {servicesList.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <div key={index} className="bg-white/40 dark:bg-stone-900/40 backdrop-blur-xl border border-white/60 dark:border-stone-800/50 rounded-3xl p-6 shadow-xl flex flex-col justify-between transition-all duration-300">
                <div>
                  <div className="w-12 h-12 rounded-2xl bg-stone-900 dark:bg-stone-100 text-white dark:text-stone-900 flex items-center justify-center mb-6 shadow-md">
                    <IconComponent size={24} />
                  </div>
                  <h3 className="text-xl font-serif font-semibold text-stone-900 dark:text-stone-50 mb-2">{service.title}</h3>
                  <p className="text-sm text-stone-600 dark:text-stone-400 leading-relaxed mb-6">{service.description}</p>
                  
                  <div className="space-y-2">
                    <p className="text-xs font-semibold uppercase tracking-wider text-stone-400 dark:text-stone-500 mb-3">Available Procedures & Modules</p>
                    <ul className="space-y-2">
                      {service.items.map((item, idx) => (
                        <li key={idx} className="flex items-center gap-2 text-sm text-stone-700 dark:text-stone-300">
                          <span className="w-1.5 h-1.5 rounded-full bg-stone-900 dark:bg-stone-100"></span>
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Patient Service Bookings Section */}
        <div className="bg-white/60 dark:bg-stone-900/60 backdrop-blur-xl border border-white/80 dark:border-stone-800/80 rounded-3xl p-8 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div>
              <h3 className="text-2xl font-serif font-semibold text-stone-900 dark:text-stone-50">Patient Service Records</h3>
              <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">Track patient appointments, booking dates, and selected treatment modules.</p>
            </div>
            <button
              onClick={() => setShowModal(true)}
              className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 dark:bg-stone-100 dark:hover:bg-stone-200 text-white dark:text-stone-900 text-sm font-semibold shadow-md transition-all"
            >
              <Plus size={16} /> Add Record
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="bg-stone-100/70 dark:bg-stone-800/60 text-stone-500 dark:text-stone-400 text-xs uppercase tracking-wider">
                <tr>
                  <th className="px-4 py-3.5 font-semibold rounded-l-xl">Patient Name</th>
                  <th className="px-4 py-3.5 font-semibold">Service Selected</th>
                  <th className="px-4 py-3.5 font-semibold">Date of Booking</th>
                  <th className="px-4 py-3.5 font-semibold rounded-r-xl">Time of Visit</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 dark:divide-stone-800/60">
                {patients.map((p) => (
                  <tr key={p.id} className="hover:bg-stone-50/50 dark:hover:bg-stone-800/30 transition-colors">
                    <td className="px-4 py-4 font-semibold text-stone-900 dark:text-stone-100 flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-stone-200 dark:bg-stone-800 flex items-center justify-center text-stone-700 dark:text-stone-300 text-xs font-bold">
                        {p.name.substring(0, 2).toUpperCase()}
                      </div>
                      {p.name}
                    </td>
                    <td className="px-4 py-4">
                      <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-stone-100 dark:bg-stone-800 text-stone-800 dark:text-stone-200 border border-stone-200 dark:border-stone-700">
                        {p.service}
                      </span>
                    </td>
                    <td className="px-4 py-4 text-stone-600 dark:text-stone-300">
                      <div className="flex items-center gap-1.5">
                        <Calendar size={14} className="text-stone-400" />
                        {p.date}
                      </div>
                    </td>
                    <td className="px-4 py-4 text-stone-600 dark:text-stone-300">
                      <div className="flex items-center gap-1.5">
                        <Clock size={14} className="text-stone-400" />
                        {p.time}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Add Patient Record Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-stone-900/40 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setShowModal(false)}>
          <div onClick={(e) => e.stopPropagation()} className="w-full max-w-md rounded-3xl bg-white dark:bg-stone-900 p-8 space-y-6 shadow-2xl border border-stone-200 dark:border-stone-800 animate-fade-in">
            <div className="flex items-center justify-between">
              <h3 className="font-serif font-semibold text-xl text-stone-900 dark:text-stone-50">Add Patient Service Record</h3>
              <button type="button" onClick={() => setShowModal(false)} className="text-stone-400 hover:text-stone-900 dark:hover:text-stone-50">
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-600 dark:text-stone-400 uppercase tracking-wider mb-1.5">Patient Name</label>
                <input
                  required
                  placeholder="Enter patient full name"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-sm text-stone-900 dark:text-stone-100 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-600 dark:text-stone-400 uppercase tracking-wider mb-1.5">Select Service Module</label>
                <select
                  value={form.service}
                  onChange={(e) => setForm({ ...form, service: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-sm text-stone-900 dark:text-stone-100 outline-none"
                >
                  {servicesList.map((category) => (
                    <optgroup key={category.title} label={category.title}>
                      {category.items.map((item) => (
                        <option key={item} value={item}>{item}</option>
                      ))}
                    </optgroup>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-600 dark:text-stone-400 uppercase tracking-wider mb-1.5">Date of Booking</label>
                  <input
                    required
                    type="date"
                    value={form.date}
                    onChange={(e) => setForm({ ...form, date: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-sm text-stone-900 dark:text-stone-100 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-stone-600 dark:text-stone-400 uppercase tracking-wider mb-1.5">Time of Visit</label>
                  <input
                    required
                    type="text"
                    placeholder="e.g. 10:30 AM"
                    value={form.time}
                    onChange={(e) => setForm({ ...form, time: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-sm text-stone-900 dark:text-stone-100 outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-stone-900 hover:bg-stone-800 dark:bg-stone-100 dark:hover:bg-stone-200 text-white dark:text-stone-900 text-sm font-semibold transition-all mt-2"
              >
                Save Record
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}