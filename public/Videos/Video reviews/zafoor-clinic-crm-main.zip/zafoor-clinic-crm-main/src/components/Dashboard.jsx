import React, { useState, useEffect } from 'react';
import { ChevronRight, ChevronLeft, Plus, Activity } from 'lucide-react';

export default function ClinicCRM() {
  const [currentDate, setCurrentDate] = useState(new Date(2026, 7, 1));
  const [selectedDate, setSelectedDate] = useState(7);
  
  const [schedules, setSchedules] = useState(() => {
    const saved = localStorage.getItem('clinic_crm_schedules');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Failed to load schedules', e);
      }
    }
    return [{ id: 1, doctor: 'Dr. Olivia Grant', patient: 'Sarah Miller' }];
  });

  useEffect(() => {
    localStorage.setItem('clinic_crm_schedules', JSON.stringify(schedules));
  }, [schedules]);

  const [isAdding, setIsAdding] = useState(false);
  const [newSchedule, setNewSchedule] = useState({ doctor: '', patient: '' });

  const metrics = [
    { label: 'Total Appointments', value: '250' },
    { label: 'Total Patients', value: '3,150' },
    { label: 'Active Patients', value: '1,842' }
  ];

  const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const timeSlots = ['9 AM', '11 AM', '1 PM', '3 PM', '5 PM'];
  
  const heatmapData = [
    [20, 60, 90, 40, 30],
    [40, 80, 50, 70, 40],
    [30, 90, 100, 60, 50],
    [50, 40, 60, 80, 70],
    [70, 90, 40, 30, 20],
    [80, 50, 30, 20, 10]
  ];

  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
  const calendarDays = Array.from({ length: daysInMonth }, (_, i) => i + 1);

  const handleAdd = () => {
    if (newSchedule.doctor && newSchedule.patient) {
      setSchedules([{ id: Date.now(), ...newSchedule }, ...schedules]);
      setIsAdding(false);
      setNewSchedule({ doctor: '', patient: '' });
    }
  };

  const getHeatmapColor = (intensity) => {
    if (intensity > 80) return 'bg-stone-800';
    if (intensity > 50) return 'bg-stone-500';
    if (intensity > 20) return 'bg-stone-300';
    return 'bg-stone-100';
  };

  return (
    <div className="min-h-screen bg-[#F9F8F6] text-stone-800 font-sans flex antialiased">
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-20 bg-[#F9F8F6] border-b border-stone-200/60 px-8 flex justify-between items-center sticky top-0 z-10">
          <h1 className="text-xl font-serif font-semibold tracking-tight text-stone-800 flex items-center gap-2">
            <Activity size={20} className="text-stone-400" /> Dashboard Overview
          </h1>
        </header>

        <main className="p-8 max-w-7xl mx-auto w-full space-y-8">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {metrics.map((m, i) => (
              <div key={i} className="bg-white p-8 rounded-3xl border border-stone-200/60 shadow-sm flex flex-col justify-between">
                <p className="text-stone-400 text-xs font-bold tracking-[0.2em] uppercase mb-4">{m.label}</p>
                <h3 className="text-4xl font-serif font-bold text-stone-800">{m.value}</h3>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-8">
              <div className="bg-white p-8 rounded-3xl border border-stone-200/60 shadow-sm">
                <div className="flex justify-between items-center mb-8">
                  <div>
                    <h2 className="text-lg font-serif font-semibold text-stone-800">Clinical Load Heatmap</h2>
                    <p className="text-xs text-stone-400 mt-1">Patient density across weekdays and time slots</p>
                  </div>
                  <div className="flex items-center gap-3 text-[10px] font-bold text-stone-400 uppercase tracking-widest">
                    <span className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-stone-100"></div> Low</span>
                    <span className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-stone-800"></div> Peak</span>
                  </div>
                </div>
                
                <div className="flex flex-col gap-3">
                  <div className="flex ml-12 justify-between text-[11px] font-bold text-stone-400 uppercase tracking-[0.1em] px-2">
                    {timeSlots.map((time, idx) => <span key={`time-${idx}`}>{time}</span>)}
                  </div>
                  
                  {weekDays.map((day, dayIdx) => (
                    <div key={`day-${dayIdx}`} className="flex items-center gap-4 w-full">
                      <span className="text-[11px] font-bold text-stone-400 uppercase tracking-[0.1em] w-8">{day}</span>
                      <div className="flex-1 flex gap-2">
                        {heatmapData[dayIdx].map((val, timeIdx) => (
                          <div 
                            key={`cell-${dayIdx}-${timeIdx}`} 
                            className={`flex-1 h-12 rounded-xl transition-all duration-300 hover:scale-[1.02] cursor-pointer border border-stone-200/30 ${getHeatmapColor(val)}`}
                            title={`Density: ${val}%`}
                          ></div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="space-y-8">
              <div className="bg-white p-6 rounded-3xl border border-stone-200/60 shadow-sm">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-lg font-serif font-semibold text-stone-800">{monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}</h2>
                  <div className="flex gap-1">
                    <button onClick={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1))} className="p-1.5 rounded-lg hover:bg-stone-100 text-stone-500 transition-colors"><ChevronLeft size={18} /></button>
                    <button onClick={() => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1))} className="p-1.5 rounded-lg hover:bg-stone-100 text-stone-500 transition-colors"><ChevronRight size={18} /></button>
                  </div>
                </div>
                <div className="grid grid-cols-7 gap-1 text-center text-xs">
                  {calendarDays.map((day) => (
                    <button key={day} onClick={() => setSelectedDate(day)} className={`h-8 w-8 mx-auto rounded-xl font-semibold transition-all ${day === selectedDate ? 'bg-stone-900 text-white shadow-md' : 'text-stone-600 hover:bg-stone-100'}`}>{day}</button>
                  ))}
                </div>
              </div>

              <div className="bg-white p-6 rounded-3xl border border-stone-200/60 shadow-sm space-y-4">
                <div className="flex justify-between items-center mb-2">
                  <h2 className="text-lg font-serif font-semibold text-stone-800">Schedules</h2>
                  <button onClick={() => setIsAdding(!isAdding)} className="p-2 rounded-xl bg-stone-900 text-white hover:bg-stone-800 transition-all shadow-md"><Plus size={16} /></button>
                </div>
                {isAdding && (
                  <div className="flex flex-col gap-3 mb-4 p-4 bg-[#FDFBF7] border border-stone-200 rounded-2xl animate-fade-in">
                    <input type="text" placeholder="Doctor Name" value={newSchedule.doctor} className="p-2.5 text-sm rounded-xl border border-stone-200 bg-white focus:outline-none focus:ring-1 focus:ring-stone-400" onChange={(e) => setNewSchedule({...newSchedule, doctor: e.target.value})} />
                    <input type="text" placeholder="Patient Name" value={newSchedule.patient} className="p-2.5 text-sm rounded-xl border border-stone-200 bg-white focus:outline-none focus:ring-1 focus:ring-stone-400" onChange={(e) => setNewSchedule({...newSchedule, patient: e.target.value})} />
                    <button onClick={handleAdd} className="bg-stone-900 text-white font-semibold text-xs py-2.5 rounded-xl hover:bg-stone-800 transition-all">Save Record</button>
                  </div>
                )}
                <div className="space-y-3 max-h-64 overflow-y-auto pr-1">
                  {schedules.map((schedule) => (
                    <div key={schedule.id} className="p-4 rounded-2xl bg-[#FDFBF7] border border-stone-100 hover:border-stone-200 transition-colors">
                      <p className="text-sm font-semibold text-stone-800">{schedule.doctor}</p>
                      <p className="text-xs text-stone-500 mt-0.5">{schedule.patient}</p>
                    </div>
                  ))}
                  {schedules.length === 0 && (
                    <p className="text-xs text-stone-400 text-center py-4">No schedules recorded yet.</p>
                  )}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}