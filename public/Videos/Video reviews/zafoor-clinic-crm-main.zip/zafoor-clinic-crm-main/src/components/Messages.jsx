import { useState } from 'react';

export default function Messages() {
  const [msg, setMsg] = useState('');

  const sendBulk = (e) => {
    e.preventDefault();
    alert('Bulk message sent to all registered patients.');
    setMsg('');
  };

  return (
    <div className="p-8 lg:p-12 bg-[#F9F8F6] min-h-screen">
      <div className="max-w-3xl mx-auto">
        <h2 className="text-3xl font-serif text-stone-800 mb-8 font-semibold tracking-tight">Patient Communications</h2>
        <form onSubmit={sendBulk} className="bg-white p-8 lg:p-10 border border-stone-200/60 rounded-3xl shadow-sm">
          <label className="block text-stone-400 text-xs font-bold tracking-[0.2em] uppercase mb-4">Bulk Message Broadcast</label>
          <textarea 
            value={msg} 
            onChange={(e) => setMsg(e.target.value)} 
            required 
            className="w-full p-6 bg-[#FDFBF7] border border-stone-200 rounded-2xl focus:outline-none focus:ring-1 focus:ring-stone-400 focus:border-stone-400 min-h-[180px] font-sans text-stone-700 text-sm leading-relaxed transition-all resize-y" 
            placeholder="Type your clinic update, festival offer, or announcement here..."
          ></textarea>
          <div className="mt-8 flex justify-end">
            <button type="submit" className="px-10 py-3.5 bg-stone-900 text-white font-sans text-sm font-semibold tracking-wide rounded-xl hover:bg-stone-800 transition-all shadow-md hover:shadow-lg transform hover:-translate-y-0.5">
              Send Broadcast
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}