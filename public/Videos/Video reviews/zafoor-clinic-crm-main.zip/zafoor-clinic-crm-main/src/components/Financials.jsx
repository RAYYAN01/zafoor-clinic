import { useState, useEffect } from 'react';
import { Plus, TrendingUp, TrendingDown, Wallet, CheckCircle } from 'lucide-react';

export default function Financials({ role }) {
  if (role !== 'doctor' && role !== 'receptionist') {
    return <div className="p-10 text-center font-serif text-stone-500">Access Restricted.</div>;
  }

  const [transactions, setTransactions] = useState(() => {
    const saved = localStorage.getItem('clinic_financial_records');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return [
      { id: 1, date: '2026-08-01', type: 'investment', amount: 1500000, description: 'Initial Clinic Setup & Equipment' },
      { id: 2, date: '2026-08-05', type: 'profit', amount: 850000, description: 'August Net Revenue' }
    ];
  });

  useEffect(() => {
    localStorage.setItem('clinic_financial_records', JSON.stringify(transactions));
  }, [transactions]);

  const [showAdd, setShowAdd] = useState(false);
  const [newTx, setNewTx] = useState({ type: 'investment', amount: '', description: '', date: '' });
  const [successMsg, setSuccessMsg] = useState(false);

  const totalInvestment = transactions.filter(t => t.type === 'investment').reduce((sum, t) => sum + Number(t.amount), 0);
  const totalProfit = transactions.filter(t => t.type === 'profit').reduce((sum, t) => sum + Number(t.amount), 0);

  const handleAdd = (e) => {
    e.preventDefault();
    const newEntry = {
      id: Date.now(),
      date: newTx.date || new Date().toISOString().split('T')[0],
      type: newTx.type,
      amount: Number(newTx.amount),
      description: newTx.description
    };
    setTransactions([newEntry, ...transactions]);
    setNewTx({ type: 'investment', amount: '', description: '', date: '' });
    if (role === 'doctor') setShowAdd(false);
    
    setSuccessMsg(true);
    setTimeout(() => setSuccessMsg(false), 3000);
  };

  return (
    <div className="p-8 lg:p-12 bg-[#F9F8F6] min-h-screen">
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-10 gap-4">
          <div>
            <h2 className="text-3xl font-serif text-stone-800 font-semibold tracking-tight">Financial Analytics</h2>
            <p className="text-sm font-sans text-stone-500 mt-2">
              {role === 'doctor' ? 'Private ledger for Dr. Mufeeda Roohi' : 'Log Daily Financial Transactions'}
            </p>
          </div>
          {role === 'doctor' && (
            <button onClick={() => setShowAdd(!showAdd)} className="flex items-center gap-2 px-6 py-3 bg-stone-900 text-white font-sans text-sm font-semibold rounded-xl hover:bg-stone-800 transition-all shadow-md">
              <Plus size={18} /> {showAdd ? 'Hide Form' : 'Add Record'}
            </button>
          )}
        </div>

        {successMsg && (
          <div className="mb-6 p-4 bg-stone-100 border border-stone-200 text-stone-800 rounded-xl flex items-center gap-3">
            <CheckCircle size={20} className="text-stone-600" />
            <p className="text-sm font-semibold">Record successfully logged to the secure ledger.</p>
          </div>
        )}

        {(showAdd || role === 'receptionist') && (
          <form onSubmit={handleAdd} className="bg-white p-6 lg:p-8 border border-stone-200/60 rounded-3xl shadow-sm mb-10 animate-fade-in">
            <h3 className="text-lg font-serif text-stone-800 font-semibold mb-6">New Ledger Entry</h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div>
                <label className="block text-stone-400 text-xs font-bold tracking-[0.1em] uppercase mb-2">Type</label>
                <select value={newTx.type} onChange={(e) => setNewTx({...newTx, type: e.target.value})} className="w-full p-3.5 bg-[#FDFBF7] border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-stone-400 text-sm">
                  <option value="investment">Investment / Expense</option>
                  <option value="profit">Profit / Revenue</option>
                </select>
              </div>
              <div>
                <label className="block text-stone-400 text-xs font-bold tracking-[0.1em] uppercase mb-2">Amount (₹)</label>
                <input type="number" required value={newTx.amount} onChange={(e) => setNewTx({...newTx, amount: e.target.value})} className="w-full p-3.5 bg-[#FDFBF7] border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-stone-400 text-sm" placeholder="e.g. 50000" />
              </div>
              <div>
                <label className="block text-stone-400 text-xs font-bold tracking-[0.1em] uppercase mb-2">Date</label>
                <input type="date" required value={newTx.date} onChange={(e) => setNewTx({...newTx, date: e.target.value})} className="w-full p-3.5 bg-[#FDFBF7] border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-stone-400 text-sm" />
              </div>
              <div>
                <label className="block text-stone-400 text-xs font-bold tracking-[0.1em] uppercase mb-2">Description</label>
                <input type="text" required value={newTx.description} onChange={(e) => setNewTx({...newTx, description: e.target.value})} className="w-full p-3.5 bg-[#FDFBF7] border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-stone-400 text-sm" placeholder="e.g. Laser Machine" />
              </div>
            </div>
            <div className="mt-6 flex justify-end gap-3">
              {role === 'doctor' && (
                <button type="button" onClick={() => setShowAdd(false)} className="px-6 py-3 text-stone-500 font-semibold text-sm hover:bg-stone-100 rounded-xl transition-all">Cancel</button>
              )}
              <button type="submit" className="px-8 py-3 bg-stone-900 text-white font-semibold text-sm rounded-xl hover:bg-stone-800 transition-all shadow-md">Log Transaction</button>
            </div>
          </form>
        )}

        {role === 'doctor' && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">
              <div className="bg-white p-8 border border-stone-200/60 rounded-3xl shadow-sm flex items-center justify-between relative overflow-hidden">
                <div className="relative z-10">
                  <p className="text-stone-400 text-xs font-bold tracking-[0.2em] uppercase mb-2">Total Investment</p>
                  <p className="text-4xl font-serif font-bold text-stone-800">₹{totalInvestment.toLocaleString('en-IN')}</p>
                </div>
                <div className="w-16 h-16 rounded-full bg-stone-100 flex items-center justify-center relative z-10">
                  <TrendingDown size={28} className="text-stone-500" />
                </div>
              </div>

              <div className="bg-white p-8 border border-stone-200/60 rounded-3xl shadow-sm flex items-center justify-between relative overflow-hidden">
                <div className="relative z-10">
                  <p className="text-stone-400 text-xs font-bold tracking-[0.2em] uppercase mb-2">Net Profit</p>
                  <p className="text-4xl font-serif font-bold text-stone-800">₹{totalProfit.toLocaleString('en-IN')}</p>
                </div>
                <div className="w-16 h-16 rounded-full bg-stone-900 flex items-center justify-center relative z-10">
                  <TrendingUp size={28} className="text-white" />
                </div>
              </div>
            </div>

            <div className="bg-white border border-stone-200/60 rounded-3xl shadow-sm overflow-hidden">
              <div className="p-6 border-b border-stone-100 bg-[#FDFBF7]">
                <h3 className="text-lg font-serif text-stone-800 font-semibold flex items-center gap-2">
                  <Wallet size={20} className="text-stone-400" /> Transaction History
                </h3>
              </div>
              <div className="divide-y divide-stone-100">
                {transactions.map((tx) => (
                  <div key={tx.id} className="p-6 flex items-center justify-between hover:bg-[#FDFBF7] transition-colors">
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${tx.type === 'profit' ? 'bg-stone-900 text-white' : 'bg-stone-100 text-stone-500'}`}>
                        {tx.type === 'profit' ? <TrendingUp size={20} /> : <TrendingDown size={20} />}
                      </div>
                      <div>
                        <p className="text-stone-800 font-semibold text-sm">{tx.description}</p>
                        <p className="text-stone-400 text-xs mt-1">{new Date(tx.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</p>
                      </div>
                    </div>
                    <div className={`text-lg font-serif font-bold ${tx.type === 'profit' ? 'text-stone-900' : 'text-stone-500'}`}>
                      {tx.type === 'profit' ? '+' : '-'}₹{tx.amount.toLocaleString('en-IN')}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}