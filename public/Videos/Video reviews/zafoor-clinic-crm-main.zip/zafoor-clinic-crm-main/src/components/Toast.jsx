import { CheckCircle2, AlertTriangle, XCircle, Info, X } from 'lucide-react'
import { useData } from '../context/DataContext'

const styleMap = {
  success: {
    icon: CheckCircle2,
    ring: 'border-clinic-200 dark:border-clinic-800',
    iconColor: 'text-clinic-600 dark:text-clinic-400',
    bar: 'bg-clinic-500',
  },
  warning: {
    icon: AlertTriangle,
    ring: 'border-amber-200 dark:border-amber-800',
    iconColor: 'text-amber-600 dark:text-amber-400',
    bar: 'bg-amber-500',
  },
  error: {
    icon: XCircle,
    ring: 'border-rose-200 dark:border-rose-800',
    iconColor: 'text-rose-600 dark:text-rose-400',
    bar: 'bg-rose-500',
  },
  info: {
    icon: Info,
    ring: 'border-sky-200 dark:border-sky-800',
    iconColor: 'text-sky-600 dark:text-sky-400',
    bar: 'bg-sky-500',
  },
}

export default function ToastContainer() {
  const { toasts, dismissToast } = useData()

  return (
    <div className="fixed top-4 right-4 z-50 flex flex-col gap-2 w-80 max-w-[90vw]">
      {toasts.map((t) => {
        const s = styleMap[t.type] || styleMap.info
        const Icon = s.icon
        return (
          <div
            key={t.id}
            className={`animate-slide-in relative overflow-hidden flex items-start gap-3 rounded-xl border ${s.ring} bg-white dark:bg-slate-800 shadow-lg p-3 pr-8`}
          >
            <div className={`absolute left-0 top-0 bottom-0 w-1 ${s.bar}`} />
            <Icon size={18} className={`mt-0.5 shrink-0 ${s.iconColor}`} />
            <p className="text-sm text-slate-700 dark:text-slate-200 leading-snug">{t.message}</p>
            <button
              onClick={() => dismissToast(t.id)}
              className="absolute top-2 right-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X size={14} />
            </button>
          </div>
        )
      })}
    </div>
  )
}