1.  import React from 'react';
2.  import { Package, Plus } from 'lucide-react';
3.  
4.  export default function DispensaryStock() {
5.    const inventory = [
6.      { item: 'Adapalene 0.1% Gel', id: 'M-01', category: 'Skincare', batch: 'AD2026A', expiry: '2027-03-01', qty: '42 tubes' },
7.      { item: 'Cetirizine 10mg', id: 'M-02', category: 'Medicine', batch: 'CT119', expiry: '2026-12-15', qty: '8 strips' },
8.      { item: 'Metformin 500mg', id: 'M-03', category: 'Medicine', batch: 'MF204', expiry: '2027-05-20', qty: '60 strips' },
9.      { item: 'Glycolic Acid Peel 30%', id: 'M-04', category: 'Skincare', batch: 'GAP07', expiry: '2026-09-10', qty: '5 bottles' },
10.     { item: 'Sunscreen SPF 50', id: 'M-05', category: 'Skincare', batch: 'SS2026', expiry: '2027-01-30', qty: '30 tubes' },
11.     { item: 'Surgical Gloves (M)', id: 'M-06', category: 'Consumable', batch: 'GLV441', expiry: '2028-01-01', qty: '120 pairs' }
12.   ];
13. 
14.   return (
15.     <div className="p-8 lg:p-12 bg-gradient-to-br from-[#F9F8F6] to-[#EBE9E1] dark:from-stone-950 dark:to-stone-900 min-h-screen transition-colors duration-300">
16.       <div className="max-w-6xl mx-auto">
17.         <div className="flex items-center justify-between mb-10">
18.           <div>
19.             <h2 className="text-3xl font-serif text-stone-900 dark:text-stone-50 font-semibold tracking-tight">Dispensary Stock</h2>
20.             <p className="text-sm font-sans text-stone-600 dark:text-stone-400 mt-2">Manage medical inventory, skincare, and consumables.</p>
21.           </div>
22.           <button className="flex items-center gap-2 px-6 py-3 bg-stone-900 dark:bg-stone-100 text-white dark:text-stone-900 text-sm font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all">
23.             <Plus size={18} /> Add Item
24.           </button>
25.         </div>
26. 
27.         <div className="bg-white/40 dark:bg-stone-900/40 backdrop-blur-xl border border-white/60 dark:border-stone-800/50 rounded-3xl shadow-xl overflow-hidden">
28.           <div className="overflow-x-auto">
29.             <table className="w-full text-left border-collapse">
30.               <thead>
31.                 <tr className="border-b border-stone-200 dark:border-stone-700/50 text-sm text-stone-500 dark:text-stone-400 bg-white/50 dark:bg-stone-950/50">
32.                   <th className="p-5 font-semibold">Item</th>
33.                   <th className="p-5 font-semibold">Category</th>
34.                   <th className="p-5 font-semibold">Batch</th>
35.                   <th className="p-5 font-semibold">Expiry</th>
36.                   <th className="p-5 font-semibold text-right">Quantity</th>
37.                 </tr>
38.               </thead>
39.               <tbody className="divide-y divide-stone-200/50 dark:divide-stone-800/50">
40.                 {inventory.map((row) => (
41.                   <tr key={row.id} className="hover:bg-white/30 dark:hover:bg-stone-800/30 transition-colors">
42.                     <td className="p-5">
43.                       <p className="font-bold text-stone-900 dark:text-stone-100">{row.item}</p>
44.                       <p className="text-xs text-stone-500">{row.id}</p>
45.                     </td>
46.                     <td className="p-5">
47.                       <span className="px-3 py-1 rounded-full text-[11px] font-bold bg-stone-200/50 dark:bg-stone-800 text-stone-700 dark:text-stone-300">
48.                         {row.category}
49.                       </span>
50.                     </td>
51.                     <td className="p-5 text-sm text-stone-600 dark:text-stone-400">{row.batch}</td>
52.                     <td className="p-5 text-sm text-stone-600 dark:text-stone-400">{row.expiry}</td>
53.                     <td className="p-5 text-right font-serif font-bold text-stone-900 dark:text-stone-100">{row.qty}</td>
54.                   </tr>
55.                 ))}
56.               </tbody>
57.             </table>
58.           </div>
59.         </div>
60.       </div>
61.     </div>
62.   );
63. }