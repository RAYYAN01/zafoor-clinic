import { useState } from 'react'
import { Plus, Minus, Trash2, X, PackagePlus, AlertTriangle } from 'lucide-react'
import { useData } from '../context/DataContext'

const emptyForm = { name: '', category: 'Medicine', batch: '', qty: '', reorderLevel: '', expiry: '', unit: 'strips' }

export default function Stock() {
  const { stock, addStockItem, updateStockQty, deleteStockItem } = useData()
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState(emptyForm)
  const [filter, setFilter] = useState('All')

  const categories = ['All', 'Medicine', 'Skincare', 'Consumable']
  const filtered = filter === 'All' ? stock : stock.filter((s) => s.category === filter)

  const handleSubmit = (e) => {
    e.preventDefault()
    if (!form.name || !form.qty) return
    addStockItem({ ...form, qty: Number(form.qty), reorderLevel: Number(form.reorderLevel) || 10 })
    setForm(emptyForm)
    setShowForm(false)
  }

  return (
    <div className="animate-fade-in space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex gap-2 flex-wrap">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setFilter(c)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                filter === c
                  ? 'bg-stone-900 dark:bg-stone-100 text-white dark:text-stone-900 shadow-sm'
                  : 'bg-white dark:bg-stone-900 text-stone-500 dark:text-stone-400 border border-stone-200 dark:border-stone-800'
              }`}
            >
              {c}
            </button>
          ))}
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 dark:bg-stone-100 dark:hover:bg-stone-200 text-white dark:text-stone-900 text-sm font-semibold shadow-sm transition-all"
        >
          <PackagePlus size={16} /> Add Item
        </button>
      </div>

      <div className="rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-stone-50 dark:bg-stone-800/60">
              <tr className="text-left text-xs text-stone-500 dark:text-stone-400">
                <th className="px-4 py-3 font-semibold">Item</th>
                <th className="px-4 py-3 font-semibold">Category</th>
                <th className="px-4 py-3 font-semibold">Batch</th>
                <th className="px-4 py-3 font-semibold">Expiry</th>
                <th className="px-4 py-3 font-semibold">Quantity</th>
                <th className="px-4 py-3 font-semibold"></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((item) => {
                const isLow = item.qty <= item.reorderLevel
                return (
                  <tr key={item.id} className="border-t border-stone-100 dark:border-stone-800">
                    <td className="px-4 py-3">
                      <p className="font-semibold text-stone-700 dark:text-stone-200">{item.name}</p>
                      <p className="text-xs text-stone-400">{item.id}</p>
                    </td>
                    <td className="px-4 py-3 text-stone-500 dark:text-stone-400">{item.category}</td>
                    <td className="px-4 py-3 text-stone-500 dark:text-stone-400">{item.batch}</td>
                    <td className="px-4 py-3 text-stone-500 dark:text-stone-400">{item.expiry}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => updateStockQty(item.id, -1)}
                          className="w-6 h-6 rounded-md bg-stone-100 dark:bg-stone-800 flex items-center justify-center text-stone-500 hover:bg-stone-200 dark:hover:bg-stone-700"
                        >
                          <Minus size={12} />
                        </button>
                        <span className={`w-16 text-center text-sm font-bold ${isLow ? 'text-rose-500' : 'text-stone-700 dark:text-stone-200'}`}>
                          {item.qty} {item.unit}
                        </span>
                        <button
                          onClick={() => updateStockQty(item.id, 1)}
                          className="w-6 h-6 rounded-md bg-stone-100 dark:bg-stone-800 flex items-center justify-center text-stone-500 hover:bg-stone-200 dark:hover:bg-stone-700"
                        >
                          <Plus size={12} />
                        </button>
                        {isLow && <AlertTriangle size={14} className="text-amber-500" title="Low stock" />}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button onClick={() => deleteStockItem(item.id)} className="text-stone-300 hover:text-rose-500 transition-colors">
                        <Trash2 size={15} />
                      </button>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && <p className="text-sm text-stone-400 text-center py-10">No items in this category.</p>}
      </div>

      {showForm && (
        <div className="fixed inset-0 z-50 bg-stone-900/40 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setShowForm(false)}>
          <form onClick={(e) => e.stopPropagation()} onSubmit={handleSubmit} className="w-full max-w-md rounded-3xl bg-white dark:bg-stone-900 p-8 space-y-4 shadow-2xl relative border border-stone-200 dark:border-stone-800">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-serif font-semibold text-xl text-stone-900 dark:text-stone-50">Add Inventory Item</h3>
              <button type="button" onClick={() => setShowForm(false)} className="text-stone-400 hover:text-stone-900 dark:hover:text-stone-50"><X size={20} /></button>
            </div>
            <input required placeholder="Item name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-full px-3 py-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-sm text-stone-900 dark:text-stone-100 outline-none" />
            <div className="grid grid-cols-2 gap-3">
              <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}
                className="px-3 py-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-sm text-stone-900 dark:text-stone-100 outline-none">
                <option>Medicine</option><option>Skincare</option><option>Consumable</option>
              </select>
              <input placeholder="Unit (e.g. strips)" value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })}
                className="px-3 py-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-sm text-stone-900 dark:text-stone-100 outline-none" />
            </div>
            <input placeholder="Batch number" value={form.batch} onChange={(e) => setForm({ ...form, batch: e.target.value })}
              className="w-full px-3 py-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-sm text-stone-900 dark:text-stone-100 outline-none" />
            <div className="grid grid-cols-2 gap-3">
              <input required type="number" placeholder="Quantity" value={form.qty} onChange={(e) => setForm({ ...form, qty: e.target.value })}
                className="px-3 py-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-sm text-stone-900 dark:text-stone-100 outline-none" />
              <input type="number" placeholder="Reorder level" value={form.reorderLevel} onChange={(e) => setForm({ ...form, reorderLevel: e.target.value })}
                className="px-3 py-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-sm text-stone-900 dark:text-stone-100 outline-none" />
            </div>
            <input type="date" value={form.expiry} onChange={(e) => setForm({ ...form, expiry: e.target.value })}
              className="w-full px-3 py-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-sm text-stone-900 dark:text-stone-100 outline-none" />
            <button type="submit" className="w-full py-3 rounded-xl bg-stone-900 hover:bg-stone-800 dark:bg-stone-100 dark:hover:bg-stone-200 text-white dark:text-stone-900 text-sm font-semibold transition-all">
              Save Item
            </button>
          </form>
        </div>
      )}
    </div>
  )
}