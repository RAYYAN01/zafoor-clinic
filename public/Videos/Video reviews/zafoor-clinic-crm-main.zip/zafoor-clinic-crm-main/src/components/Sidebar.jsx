import { LayoutDashboard, ShieldPlus, Receipt, Boxes, FlaskConical, MessageSquareText, LineChart, ClipboardList, X } from 'lucide-react'

const baseNavItems = [
  { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { key: 'services', label: 'Services', icon: ShieldPlus },
  { key: 'billing', label: 'Billing', icon: Receipt },
  { key: 'stock', label: 'Dispensary Stock', icon: Boxes },
  { key: 'labs', label: 'Lab Management', icon: FlaskConical },
  { key: 'messages', label: 'Patient Messaging', icon: MessageSquareText },
]

export default function Sidebar({ active, setActive, open, setOpen, role }) {
  const navItems = role === 'doctor' 
    ? [
        baseNavItems[0],
        { key: 'patients', label: 'Patient Records', icon: ClipboardList },
        { key: 'financials', label: 'Financial Analytics', icon: LineChart },
        ...baseNavItems.slice(1)
      ]
    : baseNavItems;

  return (
    <>
      {open && (
        <div className="fixed inset-0 bg-stone-900/40 z-30 lg:hidden backdrop-blur-sm" onClick={() => setOpen(false)} />
      )}
      <aside className={`fixed lg:sticky top-0 z-40 h-screen w-72 shrink-0 bg-[#FDFBF7] border-r border-stone-200 flex flex-col transition-transform duration-300 shadow-sm ${open ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="flex items-center justify-between px-6 h-24 border-b border-stone-200 bg-[#FDFBF7]">
          {/* Logo only - text removed */}
          <div className="flex items-center">
            <img src="/zafoor logo.jpeg" alt="Zafoor Clinic Logo" className="h-12 w-auto object-contain" />
          </div>
          <button className="lg:hidden text-stone-400 hover:text-stone-600" onClick={() => setOpen(false)}><X size={20} /></button>
        </div>
        
        <nav className="flex-1 px-5 py-8 space-y-2 overflow-y-auto bg-[#FDFBF7]">
          {navItems.map(({ key, label, icon: Icon }) => {
            const isActive = active === key
            return (
              <button key={key} onClick={() => { setActive(key); setOpen(false) }}
                className={`w-full flex items-center gap-4 px-4 py-3.5 rounded-xl text-sm transition-all duration-300 ${isActive ? 'bg-stone-200/50 text-stone-900 font-semibold shadow-sm' : 'text-stone-500 font-medium hover:bg-stone-100 hover:text-stone-800'}`}>
                <Icon size={20} strokeWidth={isActive ? 2.5 : 2} className={isActive ? 'text-stone-800' : 'text-stone-400'} />
                {label}
              </button>
            )
          })}
        </nav>

        <div className="p-6 border-t border-stone-200 bg-[#FDFBF7]">
          <div className="rounded-2xl bg-white p-4 border border-stone-100 shadow-sm">
            <p className="text-sm font-bold text-stone-800 font-serif">Dr. Mufeeda Roohi</p>
            <p className="text-xs text-stone-500 font-medium mt-1">Skin Care & General Medicine</p>
          </div>
        </div>
      </aside>
    </>
  )
}