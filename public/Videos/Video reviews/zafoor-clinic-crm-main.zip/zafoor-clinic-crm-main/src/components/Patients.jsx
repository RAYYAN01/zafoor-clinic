import { useState, useEffect } from 'react';
import { Lock, Plus, Phone, Calendar, X, CheckCircle, Trash2, Edit3, Stethoscope } from 'lucide-react';

export default function PatientRecords({ role }) {
  if (role !== 'doctor') {
    return (
      <div className="p-8 lg:p-12 bg-[#F9F8F6] min-h-screen flex items-center justify-center">
        <div className="bg-white p-10 border border-stone-200/60 rounded-3xl shadow-sm text-center max-w-md">
          <div className="w-16 h-16 bg-stone-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Lock size={28} className="text-stone-500" />
          </div>
          <h2 className="text-2xl font-serif text-stone-800 font-semibold mb-2">Access Restricted</h2>
          <p className="text-sm font-sans text-stone-500">
            For patient confidentiality, only attending doctors have clearance to view detailed medical records. 
          </p>
        </div>
      </div>
    );
  }

  const serviceCategories = [
    {
      category: 'Cosmetology',
      modules: [
        'PRP & GFC', 
        'Laser Treatments', 
        'Weight Reduction', 
        'Hairfall & Dandruff Treatment', 
        'Skin Boosters', 
        'Chemical Peels & Facials', 
        'Acne Treatment'
      ]
    },
    {
      category: 'Diabetology',
      modules: [
        'HbA1c Testing', 
        'FBS & PPBS', 
        'Complication Checklists', 
        'Vital Monitoring', 
        'Diabetic Footcare'
      ]
    },
    {
      category: 'General Medicine',
      modules: [
        'Thyroid Care', 
        'Pediatrics', 
        'Gynecology', 
        'Cholesterol Management', 
        'General Consultation'
      ]
    }
  ];

  const [patients, setPatients] = useState(() => {
    const saved = localStorage.getItem('clinic_patients');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return [
      { id: 1, name: 'Rajesh Kumar', age: 42, gender: 'Male', services: ['General Consultation', 'HbA1c Testing'], lastVisit: '2026-08-04', phone: '+91 98765 43210' },
      { id: 2, name: 'Priya Sharma', age: 28, gender: 'Female', services: ['Laser Treatments', 'Acne Treatment'], lastVisit: '2026-08-05', phone: '+91 91234 56789' },
      { id: 3, name: 'Amit Patel', age: 35, gender: 'Male', services: ['FBS & PPBS', 'Vital Monitoring'], lastVisit: '2026-08-02', phone: '+91 99887 76655' },
      { id: 4, name: 'Sneha Reddy', age: 31, gender: 'Female', services: ['Pediatrics', 'Gynecology'], lastVisit: '2026-08-06', phone: '+91 94455 66778' },
      { id: 5, name: 'Vikram Singh', age: 50, gender: 'Male', services: ['Thyroid Care', 'Cholesterol Management'], lastVisit: '2026-07-28', phone: '+91 91122 33445' },
      { id: 6, name: 'Ananya Iyer', age: 24, gender: 'Female', services: ['PRP & GFC', 'Skin Boosters'], lastVisit: '2026-08-01', phone: '+91 93344 55667' },
    ];
  });

  useEffect(() => {
    localStorage.setItem('clinic_patients', JSON.stringify(patients));
  }, [patients]);

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [successMsg, setSuccessMsg] = useState('');
  
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    gender: 'Male',
    services: [],
    phone: ''
  });

  const handleServiceToggle = (service) => {
    setFormData(prev => {
      const exists = prev.services.includes(service);
      if (exists) {
        return { ...prev, services: prev.services.filter(s => s !== service) };
      } else {
        return { ...prev, services: [...prev.services, service] };
      }
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (formData.services.length === 0) {
      alert('Please select at least one service.');
      return;
    }

    if (editingId !== null) {
      setPatients(patients.map(p => p.id === editingId ? { ...p, ...formData, age: Number(formData.age) } : p));
      setSuccessMsg('Patient record updated successfully.');
    } else {
      const entry = {
        id: Date.now(),
        ...formData,
        age: Number(formData.age),
        lastVisit: new Date().toISOString().split('T')[0]
      };
      setPatients([entry, ...patients]);
      setSuccessMsg('Patient record successfully added and saved.');
    }

    resetForm();
    setTimeout(() => setSuccessMsg(''), 3000);
  };

  const handleEdit = (patient) => {
    setEditingId(patient.id);
    setFormData({
      name: patient.name,
      age: patient.age,
      gender: patient.gender,
      services: patient.services || [],
      phone: patient.phone
    });
    setShowForm(true);
  };

  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this patient record?')) {
      setPatients(patients.filter(p => p.id !== id));
      setSuccessMsg('Patient record deleted successfully.');
      setTimeout(() => setSuccessMsg(''), 3000);
    }
  };

  const resetForm = () => {
    setFormData({ name: '', age: '', gender: 'Male', services: [], phone: '' });
    setEditingId(null);
    setShowForm(false);
  };

  return (
    <div className="p-8 lg:p-12 bg-[#F9F8F6] min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-10 gap-4">
          <div>
            <h2 className="text-3xl font-serif text-stone-800 font-semibold tracking-tight">Patient Records</h2>
            <p className="text-sm font-sans text-stone-500 mt-2">Doctor's secure consultation & medical services register.</p>
          </div>
          <button 
            onClick={() => {
              if (showForm) resetForm();
              else setShowForm(true);
            }} 
            className="flex items-center gap-2 px-6 py-3 bg-stone-900 text-white font-sans text-sm font-semibold rounded-xl hover:bg-stone-800 transition-all shadow-md"
          >
            <Plus size={18} /> {showForm ? 'Cancel' : 'Add New Record'}
          </button>
        </div>

        {successMsg && (
          <div className="mb-6 p-4 bg-stone-100 border border-stone-200 text-stone-800 rounded-xl flex items-center gap-3">
            <CheckCircle size={20} className="text-stone-600" />
            <p className="text-sm font-semibold">{successMsg}</p>
          </div>
        )}

        {showForm && (
          <form onSubmit={handleSubmit} className="bg-white p-6 lg:p-8 border border-stone-200/60 rounded-3xl shadow-sm mb-10 animate-fade-in">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-serif text-stone-800 font-semibold">
                {editingId !== null ? 'Edit Patient Record' : 'New Patient Registration'}
              </h3>
              <button type="button" onClick={resetForm} className="text-stone-400 hover:text-stone-600">
                <X size={20} />
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div>
                <label className="block text-stone-400 text-xs font-bold tracking-[0.1em] uppercase mb-2">Full Name</label>
                <input 
                  type="text" 
                  required 
                  value={formData.name} 
                  onChange={(e) => setFormData({...formData, name: e.target.value})} 
                  className="w-full p-3.5 bg-[#FDFBF7] border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-stone-400 text-sm" 
                  placeholder="e.g. John Doe" 
                />
              </div>
              <div>
                <label className="block text-stone-400 text-xs font-bold tracking-[0.1em] uppercase mb-2">Age</label>
                <input 
                  type="number" 
                  required 
                  value={formData.age} 
                  onChange={(e) => setFormData({...formData, age: e.target.value})} 
                  className="w-full p-3.5 bg-[#FDFBF7] border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-stone-400 text-sm" 
                  placeholder="e.g. 34" 
                />
              </div>
              <div>
                <label className="block text-stone-400 text-xs font-bold tracking-[0.1em] uppercase mb-2">Gender</label>
                <select 
                  value={formData.gender} 
                  onChange={(e) => setFormData({...formData, gender: e.target.value})} 
                  className="w-full p-3.5 bg-[#FDFBF7] border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-stone-400 text-sm"
                >
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div className="md:col-span-3">
                <label className="block text-stone-400 text-xs font-bold tracking-[0.1em] uppercase mb-2">Phone Number</label>
                <input 
                  type="text" 
                  required 
                  value={formData.phone} 
                  onChange={(e) => setFormData({...formData, phone: e.target.value})} 
                  className="w-full p-3.5 bg-[#FDFBF7] border border-stone-200 rounded-xl focus:outline-none focus:ring-1 focus:ring-stone-400 text-sm" 
                  placeholder="e.g. +91 98765 43210" 
                />
              </div>
            </div>

            <div className="mb-6 space-y-4">
              <label className="block text-stone-400 text-xs font-bold tracking-[0.1em] uppercase">Select Services</label>
              
              {serviceCategories.map((group) => (
                <div key={group.category} className="p-4 bg-[#FDFBF7] border border-stone-200/80 rounded-2xl">
                  <h4 className="text-xs font-serif font-bold text-stone-700 uppercase tracking-wider mb-3">{group.category}</h4>
                  <div className="flex flex-wrap gap-2">
                    {group.modules.map((serviceName) => {
                      const isSelected = formData.services.includes(serviceName);
                      return (
                        <button
                          type="button"
                          key={serviceName}
                          onClick={() => handleServiceToggle(serviceName)}
                          className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all border flex items-center gap-1.5 ${
                            isSelected 
                              ? 'bg-stone-900 text-white border-stone-900 shadow-sm' 
                              : 'bg-white text-stone-600 border-stone-200 hover:border-stone-400'
                          }`}
                        >
                          <Stethoscope size={12} />
                          {serviceName}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-end gap-3">
              <button 
                type="button" 
                onClick={resetForm} 
                className="px-6 py-3 text-stone-500 font-semibold text-sm hover:bg-stone-100 rounded-xl transition-all"
              >
                Cancel
              </button>
              <button 
                type="submit" 
                className="px-8 py-3 bg-stone-900 text-white font-semibold text-sm rounded-xl hover:bg-stone-800 transition-all shadow-md"
              >
                {editingId !== null ? 'Update Record' : 'Save Record'}
              </button>
            </div>
          </form>
        )}

        <div className="bg-white border border-stone-200/60 rounded-3xl shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-stone-50/70 border-b border-stone-200/60 text-stone-400 text-xs font-bold tracking-[0.1em] uppercase">
                  <th className="py-4 px-6">Patient Name</th>
                  <th className="py-4 px-6">Age / Gender</th>
                  <th className="py-4 px-6">Phone Number</th>
                  <th className="py-4 px-6">Services</th>
                  <th className="py-4 px-6">Last Visit</th>
                  <th className="py-4 px-6 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 text-stone-700 text-sm">
                {patients.length === 0 ? (
                  <tr>
                    <td colSpan="6" className="py-8 text-center text-stone-400">No patient records found.</td>
                  </tr>
                ) : (
                  patients.map((patient) => (
                    <tr key={patient.id} className="hover:bg-stone-50/50 transition-colors">
                      <td className="py-4 px-6 font-semibold text-stone-900 flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center font-bold text-xs shrink-0">
                          {patient.name.split(' ').map(n => n[0]).join('')}
                        </div>
                        {patient.name}
                      </td>
                      <td className="py-4 px-6">{patient.gender}, {patient.age} yrs</td>
                      <td className="py-4 px-6 whitespace-nowrap">
                        <div className="flex items-center gap-2">
                          <Phone size={13} className="text-stone-400 shrink-0" />
                          <span>{patient.phone}</span>
                        </div>
                      </td>
                      <td className="py-4 px-6">
                        <div className="flex flex-wrap gap-1.5 max-w-xs">
                          {patient.services && patient.services.map((s, idx) => (
                            <span key={idx} className="text-[11px] font-semibold px-2.5 py-0.5 bg-stone-100 text-stone-600 rounded-full">
                              {s}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="py-4 px-6 whitespace-nowrap">
                        <div className="flex items-center gap-1.5 text-stone-500">
                          <Calendar size={13} className="text-stone-400 shrink-0" />
                          {new Date(patient.lastVisit).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                        </div>
                      </td>
                      <td className="py-4 px-6 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-2">
                          <button 
                            onClick={() => handleEdit(patient)} 
                            className="p-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl transition-all inline-flex items-center justify-center"
                            title="Edit Record"
                          >
                            <Edit3 size={15} />
                          </button>
                          <button 
                            onClick={() => handleDelete(patient.id)} 
                            className="p-2 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-xl transition-all inline-flex items-center justify-center"
                            title="Delete Record"
                          >
                            <Trash2 size={15} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}