import { createContext, useContext, useEffect, useState, useCallback } from 'react'
import { seedPatients, seedStock, seedLabs, seedMessages } from '../utils/seedData'

const DataContext = createContext(null)

const STORAGE_KEY = 'zafoor_clinic_crm_data_v1'

function loadInitial() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) return JSON.parse(raw)
  } catch (e) {
    console.warn('Could not read saved data, starting fresh.', e)
  }
  return {
    patients: seedPatients,
    stock: seedStock,
    labs: seedLabs,
    messages: seedMessages,
  }
}

export function DataProvider({ children }) {
  const [data, setData] = useState(loadInitial)
  const [toasts, setToasts] = useState([])

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data))
  }, [data])

  const notify = useCallback((message, type = 'success') => {
    const id = Date.now() + Math.random()
    setToasts((t) => [...t, { id, message, type }])
    setTimeout(() => {
      setToasts((t) => t.filter((toast) => toast.id !== id))
    }, 3500)
  }, [])

  const dismissToast = (id) => setToasts((t) => t.filter((toast) => toast.id !== id))

  // ---- Patients ----
  const addPatient = (patient) => {
    const id = `P-${1000 + data.patients.length + 1}`
    setData((d) => ({ ...d, patients: [{ ...patient, id, history: [] }, ...d.patients] }))
    notify(`Patient "${patient.name}" added`, 'success')
  }
  const updatePatient = (id, updates) => {
    setData((d) => ({
      ...d,
      patients: d.patients.map((p) => (p.id === id ? { ...p, ...updates } : p)),
    }))
    notify('Patient record updated', 'success')
  }
  const deletePatient = (id) => {
    setData((d) => ({ ...d, patients: d.patients.filter((p) => p.id !== id) }))
    notify('Patient record deleted', 'error')
  }
  const addPatientNote = (id, note) => {
    setData((d) => ({
      ...d,
      patients: d.patients.map((p) =>
        p.id === id
          ? { ...p, history: [{ date: new Date().toISOString().slice(0, 10), note }, ...(p.history || [])] }
          : p
      ),
    }))
    notify('Visit note added to patient history', 'success')
  }

  // ---- Stock ----
  const addStockItem = (item) => {
    const id = `M-${String(data.stock.length + 1).padStart(2, '0')}`
    setData((d) => ({ ...d, stock: [{ ...item, id }, ...d.stock] }))
    notify(`"${item.name}" added to inventory`, 'success')
  }
  const updateStockQty = (id, delta) => {
    setData((d) => ({
      ...d,
      stock: d.stock.map((s) =>
        s.id === id ? { ...s, qty: Math.max(0, s.qty + delta) } : s
      ),
    }))
    const item = data.stock.find((s) => s.id === id)
    if (item) {
      const newQty = Math.max(0, item.qty + delta)
      if (newQty <= item.reorderLevel) {
        notify(`Low stock alert: ${item.name} (${newQty} ${item.unit} left)`, 'warning')
      } else {
        notify(`${item.name} stock updated`, 'success')
      }
    }
  }
  const deleteStockItem = (id) => {
    setData((d) => ({ ...d, stock: d.stock.filter((s) => s.id !== id) }))
    notify('Inventory item removed', 'error')
  }

  // ---- Labs ----
  const addLabOrder = (order) => {
    const id = `L-${200 + data.labs.length + 1}`
    setData((d) => ({ ...d, labs: [{ ...order, id, status: 'Pending', result: null, resultDate: null }, ...d.labs] }))
    notify(`Lab test ordered for ${order.patient}`, 'success')
  }
  const updateLabStatus = (id, status, result = null) => {
    setData((d) => ({
      ...d,
      labs: d.labs.map((l) =>
        l.id === id
          ? {
              ...l,
              status,
              result: result !== null ? result : l.result,
              resultDate: status === 'Completed' ? new Date().toISOString().slice(0, 10) : l.resultDate,
            }
          : l
      ),
    }))
    notify(`Lab order ${id} marked as ${status}`, status === 'Completed' ? 'success' : 'info')
  }
  const deleteLabOrder = (id) => {
    setData((d) => ({ ...d, labs: d.labs.filter((l) => l.id !== id) }))
    notify('Lab order removed', 'error')
  }

  // ---- Messages ----
  const sendMessage = (msg) => {
    const id = `MSG-${String(data.messages.length + 1).padStart(2, '0')}`
    setData((d) => ({
      ...d,
      messages: [
        { ...msg, id, status: 'Sent', date: new Date().toISOString().slice(0, 10) },
        ...d.messages,
      ],
    }))
    notify(`Message sent to ${msg.patient} via ${msg.channel}`, 'success')
  }
  const deleteMessage = (id) => {
    setData((d) => ({ ...d, messages: d.messages.filter((m) => m.id !== id) }))
    notify('Message log removed', 'error')
  }

  const resetToSeedData = () => {
    setData({ patients: seedPatients, stock: seedStock, labs: seedLabs, messages: seedMessages })
    notify('Data reset to demo defaults', 'info')
  }

  return (
    <DataContext.Provider
      value={{
        ...data,
        toasts,
        notify,
        dismissToast,
        addPatient,
        updatePatient,
        deletePatient,
        addPatientNote,
        addStockItem,
        updateStockQty,
        deleteStockItem,
        addLabOrder,
        updateLabStatus,
        deleteLabOrder,
        sendMessage,
        deleteMessage,
        resetToSeedData,
      }}
    >
      {children}
    </DataContext.Provider>
  )
}

export function useData() {
  return useContext(DataContext)
}